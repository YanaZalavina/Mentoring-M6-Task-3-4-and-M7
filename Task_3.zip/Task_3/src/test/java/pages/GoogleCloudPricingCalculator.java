package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.*;
import utilsForDropdownList.utilForDropdownList;

import static waits.Waits.waitToBeClickableForElement;

public class GoogleCloudPricingCalculator extends AbstractPage{

    private String startPartOfPath = "//*[contains(text(), '";
    private String endPartOfPath = "')]";
    private String parentFrame = "//iframe[contains(@name, 'goog')]";
    private String childFrameTag = "iframe";
    private String xpathResultEstimateBlock = "//md-content[@ng-if='cloudCartCtrl.showComputeItems']";

    public GoogleCloudPricingCalculator(WebDriver driver){
        super(driver);
    }
    @FindBy(xpath = "//*[@class='md-select-menu-container md-active md-clickable']//md-option/div")
    private WebElement elementFromDropdownList;
    @FindBy(xpath = "//iframe[@id='myFrame']")
    private WebElement googleCloudFrame;
    @FindBy(xpath = "//div[@class='md-toolbar-tools cpc-estimate-header']")
    private WebElement estimate;
    @FindBy(xpath = "//input[@ng-model='listingCtrl.computeServer.quantity']")
    private WebElement numberOfInstancesLabel;
    @FindBy(xpath = "//input[@ng-model='listingCtrl.computeServer.quantity']")
    private WebElement numberOfInstancesInput;
    @FindBy(xpath = "//md-select-value[@id='select_value_label_59']//span[@class='md-select-icon']")
    private WebElement seriesDropdownButton;
    @FindBy(xpath = "//md-option[@value='n1']")
    private WebElement seriesN1;
    @FindBy(xpath = "//md-select-value[@id='select_value_label_60']//span[@class='md-select-icon']")
    private WebElement machineTypeDropdownButton;
    @FindBy(xpath = "//div[@class='md-select-menu-container md-active md-clickable']//md-option[@value='CP-COMPUTEENGINE-VMIMAGE-N1-STANDARD-8']")
    private WebElement machineTypeN1Standard8;
    @FindBy(xpath = "//md-checkbox[@ng-model='listingCtrl.computeServer.addGPUs']")
    private WebElement checkBoxAddGPUs;
    @FindBy(xpath = "//md-select[@ng-model='listingCtrl.computeServer.gpuCount']//span[@class='md-select-icon']")
    private WebElement numberOfGPUsDropdownButton;
    @FindBy(xpath = "//div[@class='md-select-menu-container md-active md-clickable']//md-option[@ng-repeat='item in listingCtrl.supportedGpuNumbers[listingCtrl.computeServer.gpuType]'][@value='1']")
    private WebElement numberOfGPUsEquals1;
    @FindBy(xpath = "//md-select[@ng-model='listingCtrl.computeServer.gpuType']//span[@class='md-select-icon']")
    private WebElement GPUTypeDropdownButton;
    @FindBy(xpath = "//md-option[@value='NVIDIA_TESLA_V100']")
    private WebElement GPUTypeNVIDIATeslaV100;
    @FindBy(xpath = "//md-select[@ng-model='listingCtrl.computeServer.ssd']//span[@class='md-select-icon']")
    private WebElement localSSDDropdownButton;
    @FindBy(xpath = "//div[contains(text(), '2x375')]")
    private WebElement localSSD2x375GB ;
    @FindBy(xpath = "//md-select[@ng-model='listingCtrl.computeServer.location']//span[@class='md-select-icon']")
    private WebElement datacenterLocationDropdownButton;
    @FindBy(xpath = "//div[@class='md-select-menu-container md-active md-clickable']//md-option[@value='europe-west3']")
    private WebElement datacenterLocationFrankfurt;
    @FindBy(xpath = "//md-select[@ng-model='listingCtrl.computeServer.cud']//span[@class='md-select-icon']")
    private WebElement committedUsageDropdownButton;
    @FindBy(xpath = "//div[@class='md-select-menu-container md-active md-clickable']//div[contains(text(), '1 Year')]")
    private WebElement committedUsage1Year;
    @FindBy(xpath = "//form[@name='ComputeEngineForm']//button[@aria-label='Add to Estimate']")
    private WebElement addToEstimateButton;
    @FindBy(xpath = "//div[contains(text(), 'VM class')]")
    private WebElement VMClassField;
    @FindBy(xpath = "//button[@id='email_quote']")
    private WebElement emailEstimateButton;
    @FindBy(xpath = "//input[@ng-model='emailQuote.user.email']")
    private WebElement emailInput;
    @FindBy(xpath = "//button[@aria-label='Send Email']")
    private WebElement sendEmailButton;
    @FindBy(xpath = "//div[text()='Compute Engine']")
    private WebElement computerEngineLink;
    @FindBy(xpath = "//button[@ng-click='cloudCartCtrl.removeCartItem(item)']")
    private WebElement deleteEstimateButton;

    private String createXPath(String valueOfText){
        return startPartOfPath
                +valueOfText
                +endPartOfPath;
    }

    public GoogleCloudPricingCalculator loadPage(){
        driver.switchTo().frame(driver.findElement(By.xpath(parentFrame)));
        driver.switchTo().frame(driver.findElement(By.tagName(childFrameTag)));
        PageFactory.initElements(driver, this);
        new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOf(estimate));
        return this;
    }
    public GoogleCloudPricingCalculator enterNumberOfInstances(String numberOfInstances){
        numberOfInstancesLabel.click();
        numberOfInstancesInput.sendKeys(numberOfInstances);
        return this;
    }

    public GoogleCloudPricingCalculator selectSeries(String selectedSeries){

        seriesDropdownButton.click();
        waitToBeClickableForElement(driver, elementFromDropdownList);
        new utilForDropdownList().findAndClickOnElement(driver, selectedSeries);
        return this;
    }

    public GoogleCloudPricingCalculator selectMachineType(String selectedMachineType){
        machineTypeDropdownButton.click();
        waitToBeClickableForElement(driver, elementFromDropdownList);
        new utilForDropdownList().findAndClickOnElement(driver, selectedMachineType);
        return this;
    }

    public GoogleCloudPricingCalculator activateCheckBoxAddGPUs() {
        waitToBeClickableForElement(driver, checkBoxAddGPUs);
        checkBoxAddGPUs.click();
        return this;
    }

    public GoogleCloudPricingCalculator enterNumberOfGPUs(String enteredNumberOfGPUs) {
        numberOfGPUsDropdownButton.click();
        waitToBeClickableForElement(driver, elementFromDropdownList);
        new utilForDropdownList().findAndClickOnElement(driver, enteredNumberOfGPUs);
        return this;
    }

    public GoogleCloudPricingCalculator selectGPUType(String selectedGPUType) {
        GPUTypeDropdownButton.click();
        waitToBeClickableForElement(driver, elementFromDropdownList);
        new utilForDropdownList().findAndClickOnElement(driver, selectedGPUType);
        return this;
    }


    public GoogleCloudPricingCalculator selectLocalSSD(String selectedLocalSSD){
        localSSDDropdownButton.click();
        waitToBeClickableForElement(driver, elementFromDropdownList);
        new utilForDropdownList().findAndClickOnElement(driver, selectedLocalSSD);
        return this;
    }


    public GoogleCloudPricingCalculator selectDatacenterLocation(String selectedDatacenterLocation){
        datacenterLocationDropdownButton.click();
        waitToBeClickableForElement(driver, elementFromDropdownList);
        new utilForDropdownList().findAndClickOnElement(driver, selectedDatacenterLocation);
        return this;
    }


    public GoogleCloudPricingCalculator selectCommittedUsage(String selectedCommittedUsage){
        committedUsageDropdownButton.click();
        waitToBeClickableForElement(driver, elementFromDropdownList);
        new utilForDropdownList().findAndClickOnElement(driver, selectedCommittedUsage);
        return this;
    }


    public GoogleCloudPricingCalculator clickOnAddToEstimate(){
        addToEstimateButton.click();
        return this;
    }

    public GoogleCloudPricingCalculator clickOnEmailEstimateButton(){
        emailEstimateButton.click();
        return this;
    }

    public GoogleCloudPricingCalculator enterCopiedEmail(){
        waitToBeClickableForElement(driver, emailInput);
        emailInput.click();
        emailInput.sendKeys(Keys.CONTROL, "v");
        return this;
    }

    public GoogleCloudPricingCalculator clickOnSendEmailButton(){
        sendEmailButton.click();
        return this;
    }

    public Boolean elementLocatedOnPage (String visibleNameOfWebElement){
        return driver.findElement(By.xpath(createXPath(visibleNameOfWebElement))).isDisplayed();
    }

    public GoogleCloudPricingCalculator clickOnDeleteEstimateButton(){
        deleteEstimateButton.click();
        return this;
    }

    public int countNumberOfElementsEstimateResults(){
        return driver.findElements(By.xpath(xpathResultEstimateBlock)).size();
    }

    public String getWebElementText(String visibleNameOfWebElement){
        WebElement element = driver.findElement(By.xpath(createXPath(visibleNameOfWebElement)));
        waitToBeClickableForElement(driver, element);
        return element.getText().trim();
    }

}
